# E-Authentication-using-QR-code-and-OTP

Run the project by following steps:
First of all you need to have software in your system to run it. (mySQL, php, any editor (like brackets), etc) .
Then put all those files in a folder and run Simple registration.html file.
This is how you can run the project.

This project is all about the authentication of the user if he/she has already registered their data in the database.
Basically, one with the authentic credentials can log in to its user profile other wise they are discarded. Moreover, its a two way authentication system in which user have to enter OTP and also have to scan the QR code.
